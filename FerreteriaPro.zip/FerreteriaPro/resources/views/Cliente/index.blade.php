@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Bienvenido, Cliente</h1>
            <p>Aquí puedes ver tus opciones de cliente.</p>
        </div>
    </div>
</div>
@endsection
