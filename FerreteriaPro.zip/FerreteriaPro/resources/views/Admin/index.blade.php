@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h1>Bienvenido, Administrador</h1>
            <p>Aquí puedes administrar el sistema.</p>
        </div>
    </div>
</div>
@endsection
